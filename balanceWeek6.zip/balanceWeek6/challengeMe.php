<!-- Main story  : doesn't  show up... weird???-->
<div id="myCarousel3" class="carousel slide">
    <div class="carousel-inner story">
        <a href="story.php">   <!-- Link to indiv story-->
        <div class="item">
             <img src="img/examples/politics.jpg" alt="" />
             <div class="carousel-caption">
                <p>Romney: Election outcome will be defining for American families</p>
                <p class="muted small">NBCNews.com, 6s ago  
                	<span class="label label-important">52%</span>
  					<i class="icon-chevron-right icon-white"></i>
  				</p>
             </div>
        </div>  
        </a>  
    </div>
</div> 

<!-- Sub stories - listed -->
<ul class="nav nav-tabs nav-stacked story">
  <li> 
  	<div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/romney.jpg" class="subStory"> 
		Romney vows 'big change' in Washington  		
		<br>
  		<p class="muted small">Politico - 14m ago
  		<span class="label label-important">68%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  	</a></div>
  </li>
  <li>
  	 <div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/whitehouse.jpg" class="subStory"> 
		White House says no bilateral talks scheduled for Iran		
		<br>
  		<p class="muted small">Yahoo! news - 1d ago
  		<span class="label label-success">5%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  	</a></div>
  </li>
  <li>
  	 <div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/lance.jpg" class="subStory"> 
		Lance Armstrong likely will have Boston Marathon time vacated  		
		<br>
  		<p class="muted small">Boston.com - 2d ago
  		<span class="label label-success">0%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  	</a></div>
  </li>
</ul>