<div class=" navbar-static-top navbar-inverse">
  <div class="navbar">
    <div class="navbar-inner">
    	<h5 class="navbarText">be<img src="img/icons/scales.png" class="banner"/>balanced
    		<!-- Page refresh icon, perhaps only have this present in news pages, e.g. not on profile-->
    		<a href="javascript:document.location.reload();"><i class="icon-repeat icon-white refresh"></i></a>
		</h5>
    </div>
  </div>
</div>