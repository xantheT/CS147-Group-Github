<?php
//include link to our db here... will look something like this
$link = mysql_connect('mysql-user-master.stanford.edu', 'ccs147xtravlos', 'phahfohk');
mysql_select_db('c_cs147_xtravlos');
?>