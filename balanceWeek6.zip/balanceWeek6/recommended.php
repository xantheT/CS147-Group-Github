<!-- Main story  : doesn't  show up... weird???-->
<div id="myCarousel2" class="carousel slide">
    <div class="carousel-inner story">
        <a href="story.php">   <!-- Link to indiv story-->
        <div class="item">
             <img src="img/examples/fb.jpg" alt="" />
             <div class="carousel-caption">
                <p>Facebook Is Failing In Europe — And It's All Russia's Fault</p>
                <p class="muted small">Business Insider, just now  
                	<span class="label label-info">95%</span>
  					<a href="#"><i class="icon-chevron-right icon-white"></i></a>
  				</p>
             </div>
        </div>
        </a>    
    </div>
</div>

<!-- Sub stories - listed -->
<ul class="nav nav-tabs nav-stacked story">
  <li> 
  	<div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/ford.jpg" class="subStory"> 
  		Ford will close three European plants at a cost of $1.5 billion
  		<br>
  		<p class="muted small">LA Times - 49m ago
  		<span class="label label-info">78%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  	</a></div>
  </li>
  <li>
  	 <div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/bbc.jpg" class="subStory"> 
		Syria army 'to observe ceasefire'  		
		<br>
  		<p class="muted small">BBC news - 1h ago
  		<span class="label label-info">89%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  		<br>
  	</a></div>
  </li>
  <li>
  	 <div><a href="story.php">   <!-- Link to indiv story-->
  		<img src="img/examples/trump.jpg" class="subStory"> 
		On 'The Tonight Show,' Obama pokes fun at Trump
		<br>
  		<p class="muted small">LA Times - 33m ago
  		<span class="label label-info">93%</span>
  		<i class="icon-chevron-right"></i>
  		</p>
  	</a></div>
  </li>
</ul>